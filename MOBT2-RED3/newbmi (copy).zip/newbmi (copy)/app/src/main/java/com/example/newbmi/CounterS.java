package com.example.newbmi;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Pedometer;
import com.google.appinventor.components.runtime.TextBox;

import com.google.appinventor.components.runtime.VerticalScrollArrangement;

public class CounterS extends Form implements HandlesEventDispatching {

    private
    Pedometer wStep;
    TextBox WalkSteps, DistanceW;
    Integer Steps=0;
    Double Distance=0.0;
    Button start, stop, reset, bmiScr;
    Label headingAtTop;

    protected void $define()
    {
        this.Sizing("Responsive");
        this.BackgroundColor(COLOR_BLACK);
        VerticalScrollArrangement counterMain = new VerticalScrollArrangement(this);
        counterMain.Width(LENGTH_FILL_PARENT);
        counterMain.Height(LENGTH_FILL_PARENT);
        counterMain.BackgroundColor(Component.COLOR_BLACK);

        headingAtTop = new Label(counterMain);
        headingAtTop.Text("Step Counter");
        headingAtTop.WidthPercent(100);
        headingAtTop.TextAlignment(ALIGNMENT_CENTER);
        headingAtTop.HeightPercent(10);
        headingAtTop.FontSize(25);
        headingAtTop.BackgroundColor(COLOR_GRAY);
        headingAtTop.TextColor(COLOR_BLACK);

        Label space2 = new Label(counterMain);
        space2.HeightPercent(2);

        WalkSteps = new TextBox(counterMain);
        WalkSteps.WidthPercent(100);
        WalkSteps.HeightPercent(11);
        WalkSteps.BackgroundColor(Component.COLOR_WHITE);
        WalkSteps.FontSize(60);
        WalkSteps.TextColor(Component.COLOR_BLACK);
        WalkSteps.Text(Steps.toString());
        WalkSteps.TextAlignment(ALIGNMENT_CENTER);

        Label space1 = new Label(counterMain);
        space1.HeightPercent(2);

        DistanceW = new TextBox(counterMain);
        DistanceW.WidthPercent(100);
        DistanceW.HeightPercent(11);
        DistanceW.BackgroundColor(COLOR_WHITE);
        DistanceW.FontSize(60);
        DistanceW.TextColor(COLOR_BLACK);
        DistanceW.Text(Steps.toString());
        DistanceW.TextAlignment(ALIGNMENT_CENTER);

        Label space3 = new Label(counterMain);
        space3.HeightPercent(2);

        HorizontalArrangement ButtonHolder = new HorizontalArrangement(counterMain);
        ButtonHolder.HeightPercent(10);

        start = new Button(ButtonHolder);
        start.HeightPercent(8);
        start.WidthPercent(35);
        start.Text("start");
        start.TextColor(Component.COLOR_BLACK);
        start.BackgroundColor(Component.COLOR_GREEN);

        stop = new Button(ButtonHolder);
        stop.HeightPercent(8);
        stop.WidthPercent(35);
        stop.Text("stop");
        start.TextColor(Component.COLOR_BLACK);
        stop.BackgroundColor(Component.COLOR_RED);

        reset = new Button(ButtonHolder);
        reset.HeightPercent(8);
        reset.WidthPercent(35);
        reset.Text("reset");
        start.TextColor(Component.COLOR_BLACK);
        reset.BackgroundColor(Component.COLOR_ORANGE);

        bmiScr = new Button (counterMain);
        bmiScr.Text("<= BMI Calculator <=");
        bmiScr.HeightPercent(10);
        bmiScr.WidthPercent(100);
        bmiScr.BackgroundColor(COLOR_GRAY);
        bmiScr.TextColor(COLOR_BLACK);
        bmiScr.TextAlignment(ALIGNMENT_CENTER);

        wStep = new Pedometer(counterMain);
        EventDispatcher.registerEventForDelegation(this, formName, "Click");
        EventDispatcher.registerEventForDelegation(this, formName, "WalkStep");
    }
    @Override
    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params)
    {
        dbg("dispatchEvent: " + formName + " [" + component.toString() + "] [" + componentName + "] " + eventName);
        switch (eventName)
        {
            case "Click":
                if (component.equals(start))
                {
                    wStep.Start();
                    return true;
                } else if (component.equals(stop))
                {
                    wStep.Stop();
                    return true;
                } else if (component.equals(reset))
                {
                    wStep.Reset();
                    Steps = 0;
                    Distance = 0.0;
                    WalkSteps.Text(Steps.toString());
                    DistanceW.Text(String.format("%.2f", Distance) + " M");
                    return true;
                }
                else if (component.equals(bmiScr)) {
                    dbg("A");
                    switchForm("MainActivity");
                    dbg("B");
                    return true;
                }
                break;
            case "WalkStep":
            {
               /* WalkSteps.Text(Integer.toString(wStep.WalkSteps()));*/
                dbg("B");
                dbg("WalkStep event received...");
                Steps = wStep.WalkSteps();
                WalkSteps.Text(Steps.toString());
                Distance = Steps * 0.762;
                DistanceW.Text(String.format("%.2f", Distance) + " M");
            }
        }
        return false;
    }
    public static void dbg (String debugMsg) {
        System.err.println( "~~~> " + debugMsg + " <~~~\n");
    }

}





