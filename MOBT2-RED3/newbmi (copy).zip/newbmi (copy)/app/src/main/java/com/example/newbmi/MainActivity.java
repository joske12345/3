package com.example.newbmi;

import android.content.Intent;
import android.view.View;
import android.widget.ImageView;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.PasswordTextBox;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalArrangement;

import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.WebViewer;
import com.google.appinventor.components.runtime.util.Ev3Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.text.DecimalFormat;

public class MainActivity extends Form implements HandlesEventDispatching {

    private
    VerticalScrollArrangement mainArrangement;
    TextBox weightBox, heightBox;
    Button calcButton, stepScr;
    Label resultBottom, headingTop, info;
    HorizontalArrangement dataEntryArrangement;



    protected void $define() {

        this.Sizing("Responsive");
        this.BackgroundColor(COLOR_BLACK);
        mainArrangement = new VerticalScrollArrangement(this);
        mainArrangement.WidthPercent(100);
        mainArrangement.Height(LENGTH_FILL_PARENT);
        mainArrangement.AlignHorizontal(Component.ALIGNMENT_CENTER);

        headingTop = new Label(mainArrangement);
        headingTop.Text("BMI calculator");
        headingTop.WidthPercent(100);
        headingTop.TextAlignment(ALIGNMENT_CENTER);
        headingTop.HeightPercent(10);
        headingTop.FontSize(25);
        headingTop.BackgroundColor(COLOR_GRAY);
        headingTop.TextColor(COLOR_BLACK);

        dataEntryArrangement = new HorizontalArrangement(mainArrangement);
        dataEntryArrangement.WidthPercent(LENGTH_FILL_PARENT);
        dataEntryArrangement.HeightPercent(15);

        weightBox = new TextBox(dataEntryArrangement);
        weightBox.WidthPercent(50);
        weightBox.HeightPercent(20);
        weightBox.FontSize(30);
        weightBox.TextAlignment(ALIGNMENT_CENTER);
        weightBox.Hint("Weight-Kg");
        weightBox.BackgroundColor(COLOR_RED);
        weightBox.TextColor(COLOR_BLACK);


        heightBox = new TextBox(dataEntryArrangement);
        heightBox.WidthPercent(50);
        heightBox.HeightPercent(20);
        heightBox.TextAlignment(ALIGNMENT_CENTER);
        heightBox.FontSize(30);
        heightBox.Hint("Height-M");
        heightBox.BackgroundColor(COLOR_RED);
        heightBox.TextColor(COLOR_BLACK);

        calcButton = new Button(mainArrangement);
        calcButton.Text("Calculate");
        calcButton.HeightPercent(10);
        calcButton.Width(LENGTH_FILL_PARENT);
        calcButton.BackgroundColor(COLOR_GRAY);
        calcButton.TextColor(COLOR_BLACK);

        info = new Label(mainArrangement);
        info.HeightPercent(5);
        info.FontSize(20);
        info.Width(LENGTH_FILL_PARENT);
        info.TextAlignment(ALIGNMENT_CENTER);

        resultBottom = new Label(mainArrangement);
        resultBottom.HeightPercent(10);
        resultBottom.FontSize(50);
        resultBottom.Width(LENGTH_FILL_PARENT);
        resultBottom.TextAlignment(ALIGNMENT_CENTER);
        resultBottom.BackgroundColor(COLOR_GRAY);
        resultBottom.TextColor(COLOR_BLACK);

        Label space1 = new Label(mainArrangement);
        space1.HeightPercent(2);

        stepScr = new Button (mainArrangement);
        stepScr.Text("=> Step Counter =>");
        stepScr.HeightPercent(10);
        stepScr.WidthPercent(100);
        stepScr.BackgroundColor(COLOR_GRAY);
        stepScr.TextColor(COLOR_BLACK);
        stepScr.TextAlignment(ALIGNMENT_CENTER);

        EventDispatcher.registerEventForDelegation(this, formName, "Click");

    }


    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params) {

        if (eventName.equals("Click")) {
            if (component.equals(calcButton)) {
                Integer persons_bmi = calculateTheBmi();
                System.err.print("A");
                System.err.print(persons_bmi);
                final Integer underweight = 18;
                final Integer normal = 24;
                final Integer overweight = 30;
                final Integer obese = 31;

                if (persons_bmi < underweight) {
                    info.Text("Underweight");
                    info.TextColor(COLOR_YELLOW);
                    info.TextAlignment(ALIGNMENT_CENTER);
                    System.err.print("B");

                } else if (persons_bmi < normal) {
                    info.Text("Normal");
                    info.TextColor(COLOR_GREEN);
                    info.TextAlignment(ALIGNMENT_CENTER);
                    System.err.print("C");

                } else if (persons_bmi < overweight) {
                    info.Text("Overweight");
                    info.TextColor(COLOR_ORANGE);
                    info.TextAlignment(ALIGNMENT_CENTER);
                    System.err.print("D");
                }
                else
                {
                    info.Text("Obese");
                    info.TextColor(COLOR_RED);
                    info.TextAlignment(ALIGNMENT_CENTER);
                  // obese
                }
                return true;
            }
            else if (component.equals(stepScr)) {
                dbg("A");
                switchForm("CounterS");
                dbg("B");
                return true;
            }

        }
        return false;
    }


    Integer calculateTheBmi() {
        Integer answer = null;
        try {
            answer = 0;
            Double weight = 0.0, height = 0.0, bmi_result = 0.0;
            if (!weightBox.Text().equals("")) {
                weight = Double.valueOf(weightBox.Text());
            }
            if (!heightBox.Text().equals("")) {
                height = Double.valueOf(heightBox.Text());
            }
            bmi_result = 0.0;
            if ((height != Double.valueOf(0)) && (weight != Double.valueOf(0))) {
                bmi_result = weight / (height * height);
                DecimalFormat df = new DecimalFormat();
                df.setMaximumFractionDigits(0); //this is round up !
                resultBottom.Text(df.format(bmi_result));
                answer = Integer.valueOf(df.format(bmi_result));
            } else {
                resultBottom.Text("0");
                answer = 0;
            }

        } catch (Exception e) {
            resultBottom.FontSize(20);
            resultBottom.Text(e.toString());
            resultBottom.Text("Please enter number");

        }
        return answer;
    }
    public static void dbg (String debugMsg) {
        System.err.println( "~~~> " + debugMsg + " <~~~\n");
    }
}









